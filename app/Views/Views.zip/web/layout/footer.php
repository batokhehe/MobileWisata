<footer class="light bg-image">
    <div class="bg-overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-lg-4">
                <h3>Wisata</h3>
                <p>Semua isi yang tercantum di dalam situs ini bertujuan untuk memberikan informasi dan bukan sebagai tujuan komersial.</p>
            </div>
            <div class="col-lg-4">
                <h3>Contacts</h3>
                <ul class="icon-list icon-line">
                    <li>Bandung, Indonesia</li>
                    <li>hello@example.com</li>
                    <li>02 123 333 444</li>
                </ul>
            </div>
            <div class="col-lg-4">
                <div class="icon-links icon-social icon-links-grid social-colors">
                    <a class="facebook"><i class="icon-facebook"></i></a>
                    <a class="twitter"><i class="icon-twitter"></i></a>
                    <a class="instagram"><i class="icon-instagram"></i></a>
                </div>
                <hr class="space-sm" />
                <p>Follow us on the social media.</p>
            </div>
        </div>
    </div>
    <div class="footer-bar">
        <div class="container">
            <span>WISATA © 2022 WARBRAIN Creative.</span>
            <span><a href="contacts.html">Contact us</a> | <a href="#">Privacy policy</a></span>
        </div>
    </div>
</footer>
