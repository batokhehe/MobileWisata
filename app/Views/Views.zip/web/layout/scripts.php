<script type="text/javascript" src="<?php echo base_url('assets/web/resources/scripts/jquery.min.js') ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/web/resources/scripts/bootstrap.min.js') ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/web/resources/scripts/main.js') ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/web/resources/scripts/parallax.min.js') ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/web/resources/scripts/glide.min.js') ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/web/resources/scripts/magnific-popup.min.js') ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/web/resources/scripts/tab-accordion.js') ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/web/resources/scripts/imagesloaded.min.js') ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/web/resources/scripts/pagination.min.js') ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/web/resources/scripts/star-rating.min.js') ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/web/resources/scripts/krajee-svg/theme.min.js') ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/web/resources/scripts/isotope.min.js') ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/web/resources/scripts/progress.js') ?>" async></script>

<script type="text/javascript" src="<?php echo base_url('assets/web/resources/scripts/custom.js') ?>" async></script>