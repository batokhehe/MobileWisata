<link rel="icon" href="images/elements/favicon.png">
<link rel="stylesheet" href="<?php echo base_url('assets/web/resources/css/bootstrap.min.css') ?>">
<link rel="stylesheet" href="<?php echo base_url('assets/web/resources/css/bootstrap-grid.css') ?>">
<link rel="stylesheet" href="<?php echo base_url('assets/web/resources/css/style.css') ?>">
<link rel="stylesheet" href="<?php echo base_url('assets/web/resources/css/glide.css') ?>">
<link rel="stylesheet" href="<?php echo base_url('assets/web/resources/css/magnific-popup.css') ?>">
<link rel="stylesheet" href="<?php echo base_url('assets/web/resources/css/content-box.css') ?>">
<link rel="stylesheet" href="<?php echo base_url('assets/web/resources/css/contact-form.css') ?>">
<link rel="stylesheet" href="<?php echo base_url('assets/web/resources/css/media-box.css') ?>">
<link rel="stylesheet" href="<?php echo base_url('assets/web/resources/css/star-rating.min.css') ?>">
<link rel="stylesheet" href="<?php echo base_url('assets/web/resources/scripts/krajee-svg/theme.min.css') ?>">
<link rel="stylesheet" href="<?php echo base_url('assets/web/resources/fonts/icons/iconsmind/line-icons.min.css') ?>">
<link rel="stylesheet" href="<?php echo base_url('assets/web/resources/fonts/line-awesome/css/line-awesome.min.css') ?>">
<link rel="stylesheet" href="<?php echo base_url('assets/web/resources/css/skin.css') ?>">