<div class="modal fade" id="modal-form" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" class="fa fa-times"></span>
                </button>
                <h4 class="modal-title"></h4>
            </div>
            <div class="modal-body">
                <?php echo $_modals_form ?>
            </div>
        </div>
    </div>
</div>
