<!-- Left navbar links -->
<ul class="navbar-nav">
    <li class="nav-item">
    <a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars"></i></a>
    </li>
</ul>

<!-- Right navbar links -->
<ul class="navbar-nav ml-auto">
    <li class="nav-item">
        <?php echo anchor('admin/auth/logout', '<i class="fa fa-power-off"></i> &nbsp; Sign out', array('class' => 'nav-link')); ?>        
    </li>
</ul>